#!/usr/bin/env python3
"""Run Codex test subprocesses without letting them mutate the active config."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


COPIED_STATE_FILES = (
    "config.toml",
    "auth.json",
    "installation_id",
    "models_cache.json",
)

def active_codex_home() -> Path:
    configured = os.environ.get("CODEX_HOME")
    return Path(configured).expanduser().resolve() if configured else (Path.home() / ".codex").resolve()


@contextmanager
def isolated_codex_environment(source_home: Path | None = None) -> Iterator[dict[str, str]]:
    """Yield an environment whose HOME and CODEX_HOME are disposable fixtures.

    The source config is copied once as read-only input and is never reopened for
    comparison. HOME is isolated too because some Codex components may fall back
    to ``~/.codex`` even when the parent process supplies CODEX_HOME. Concurrent
    edits made by the user to the active config are unrelated to the test.
    """

    requested_source = (source_home or active_codex_home()).expanduser()
    source = requested_source.resolve()
    source_config = source / "config.toml"
    if not source_config.is_file():
        raise RuntimeError(f"missing source Codex config: {source_config}")
    with tempfile.TemporaryDirectory(prefix="codex-test-home-") as temporary:
        temporary_root = Path(temporary)
        isolated_home = temporary_root / "home"
        isolated = isolated_home / ".codex"
        isolated.mkdir(parents=True)
        for name in COPIED_STATE_FILES:
            candidate = source / name
            if candidate.is_file():
                shutil.copy2(candidate, isolated / name)
        copied_config = isolated / "config.toml"
        copied_text = copied_config.read_text(encoding="utf-8")
        for source_spelling in {str(requested_source), str(source), "~/.codex", "$HOME/.codex"}:
            copied_text = copied_text.replace(source_spelling, str(isolated))
        # A regression subprocess must not notify or wake the live desktop app.
        copied_lines = [
            "notify = []" if line.startswith("notify = ") else line
            for line in copied_text.splitlines()
        ]
        copied_config.write_text("\n".join(copied_lines) + "\n", encoding="utf-8")

        xdg_config = isolated_home / ".config"
        xdg_cache = isolated_home / ".cache"
        xdg_data = isolated_home / ".local" / "share"
        temp_dir = temporary_root / "tmp"
        security_preferences = isolated_home / "Library" / "Preferences"
        for directory in (xdg_config, xdg_cache, xdg_data, temp_dir, security_preferences):
            directory.mkdir(parents=True, exist_ok=True)
        # Changing HOME hides the macOS default keychain. Point only the
        # disposable HOME preference at the existing login keychain so Codex
        # can read its platform credential without regaining a path to
        # ~/.codex/config.toml.
        login_keychain = source.parent / "Library" / "Keychains" / "login.keychain-db"
        if sys.platform == "darwin" and login_keychain.is_file():
            keychain_env = os.environ.copy()
            keychain_env["HOME"] = str(isolated_home)
            subprocess.run(
                ["security", "default-keychain", "-d", "user", "-s", str(login_keychain)],
                check=True,
                capture_output=True,
                text=True,
                env=keychain_env,
            )
        env = os.environ.copy()
        env["HOME"] = str(isolated_home)
        env["CODEX_HOME"] = str(isolated)
        env["XDG_CONFIG_HOME"] = str(xdg_config)
        env["XDG_CACHE_HOME"] = str(xdg_cache)
        env["XDG_DATA_HOME"] = str(xdg_data)
        env["TMPDIR"] = str(temp_dir)
        yield env
